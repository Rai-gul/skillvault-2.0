import React, { useContext } from 'react'
import { AuthContext } from './AuthContext'
import LoginForm from './components/LoginForm'
import NoteList from './components/NoteList'

export default function App() {
  const { user, login, logout } = useContext(AuthContext)

  if (!user) {
    return <LoginForm onLogin={login} />
  }

  return (
    <div>
      <button onClick={logout}>Logout</button>
      <h1>Your Notes</h1>
      <NoteList />
    </div>
  )
}
